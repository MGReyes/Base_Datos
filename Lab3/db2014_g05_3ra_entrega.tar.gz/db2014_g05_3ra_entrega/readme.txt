Base de datos - Tercera Entrega - Grupo 5

Para probar consultas con php:
www.famaf.unc.edu.ar/~drp0112/php

